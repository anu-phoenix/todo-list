#include <bits/stdc++.h>
using namespace std;

int main()
{
    cout << "Enter your string" << endl;
    string s;
    cin >> s;

    stack<char> stack;
    int count0=0,count1=0;

    if (s[0] == '0')
    {
        stack.push(s[0]);
        count0++;
    }
    else
    {
        cout << "NO" << endl;
        return 0;
    }

    for (int i = 1; i < s.length(); i++)
    {
        
            if (stack.top() == '0' && s[i] == '0')
            {
                stack.push(s[i]);
                 count0++;
            }
            else if (stack.top() == '0' && s[i] == '1')
            {  
               
                
                stack.push(s[i]);
                count1++;
            
            }
            else if(stack.top() == '1' && s[i] == '1'){

                count1++;
            }
           
            else
            {
                cout << "NO" << endl;
                return 0;
            }
        }
        if (count0==count1)
        {
            cout << "YES" << endl;
        }
        else
        {  
        
            cout << "NO" << endl;
        }
    }